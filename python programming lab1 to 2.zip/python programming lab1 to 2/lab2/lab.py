# NO IMPORTS ALLOWED!

import json

def get_id(actor_name, actor_dict):
    if actor_name in actor_dict:
        return actor_dict[actor_name]
    
def get_name(actor_id, actor_dict):
    for name, num in actor_dict.items():
        if num == actor_id:
            return name
        
def get_film_name(film_id, film_dict):
    for name, num in film_dict.items():
        if num == film_id:
            return name
    
def did_x_and_y_act_together(data, actor_id_1, actor_id_2):
    value = False
    for film in data:
        if actor_id_1 in film and actor_id_2 in film:
            value = True
            break
    return value

class Social(object):
    """Represents a road map -> a directed graph of Node and DirectedRoad objects"""

    def __init__(self):
        self.actors = set()
        self.neighbor = {}

    def get_neighbor(self, actor):
        if actor in self.neighbor:
            return self.neighbor[actor]
        else:
            return []

    def get_all_actors(self):
        return self.actors
    
    def get_all_neighbor(self):
        return self.neighbor

    def has_actor(self, actor):
        return actor in self.actors

    def add_actor(self, actor):
        if actor in self.actors:
            raise ValueError
        else:
            self.actors.add(actor)
            self.neighbor[actor] = []

    def add_neighbor(self, actor, n_actor):
        if actor not in self.neighbor or n_actor not in self.neighbor:
            raise ValueError
        else:
            self.neighbor[actor].append(n_actor)
        
            

def get_social(data):
    actor_social = Social()
    for film in data:
        actor = film[0]
        actor_n = film[1]
        if actor not in actor_social.get_all_actors():
            actor_social.add_actor(actor)
        if actor_n not in actor_social.get_all_actors():
            actor_social.add_actor(actor_n)
        actor_social.add_neighbor(actor, actor_n)
        actor_social.add_neighbor(actor_n, actor)
    return actor_social
        
def get_film(data):
    film_dict = {}
    for film in data:
        film_dict[(film[0], film[1])] = film[2]
        film_dict[(film[1], film[0])] = film[2]
    return film_dict

#def get_next_actor (data, current_a):
#    actor_dict = get_social(data).get_all_neighbor()
#    return actor_dict[current_a]
#
#def get_all_actor(data):
#    actor_set = get_social(data).get_all_actors()
#    return list(actor_set)
    
def get_actors_with_bacon_number(data, n):
    bacon_dict = {}
    path = {}
    social_actor = get_social(data)
    neighbor_actor = social_actor.get_all_neighbor()
    unlabel = social_actor.get_all_actors()
    
    for i in unlabel:
        path[i] = None
        bacon_dict[i] = float('inf')
    start = 4724     # initialize actor with bacon number 0
    bacon_dict[start] = 0
    while unlabel:
        current_a = min(unlabel, key = lambda actor: bacon_dict[actor])
#        print(bacon_dict[current_a])
        if bacon_dict[current_a] > n:
            break
        next_a = neighbor_actor[current_a]
#        print(next_a)
        for i in next_a:
            next_bacon = bacon_dict[current_a] + 1
            if next_bacon < bacon_dict[i]:
                bacon_dict[i] = next_bacon
                path[i] = current_a
        unlabel.remove(current_a)
    
    bacon_set = set()  
    for i in bacon_dict:
        if bacon_dict[i] == n:
            bacon_set.add(i)
        
    return bacon_set
            
def get_bacon_path(data, actor_id):
#    start = 4724
#    path = []
#    path.append(start)
#    visited = set()
#    visited.add(start)
#    next_a = get_next_actor(data, current_id)
#    
#    if actor_id == start:
#        return []
#    else:
#        while current:
#            current_id = current.pop(0)
#            path.append(current_id)
#            next_a = get_next_actor(data, current_id)
#            for i in next_a:
#                if i not in path and i not in current:
#                    current.append(i)
#        return path
           
#    bacon_dict = {}
#    path = {}
#    social_actor = get_social(data)
#    unlabel = social_actor.get_all_actors()
#    neighbor_actor = social_actor.get_all_neighbor()
#    for i in unlabel:
#        path[i] = None
#        bacon_dict[i] = float('inf')
#        
#    start = 4724     # initialize actor with bacon number 0
#    bacon_dict[start] = 0
#    while unlabel:
#        current_a = min(unlabel, key = lambda actor: bacon_dict[actor])
##        print(bacon_dict[current_a])
#        if bacon_dict[current_a] > 6:
#            break
#        next_a = neighbor_actor[current_a]
#        next_bacon = bacon_dict[current_a] + 1
#        if actor_id in next_a:
#            bacon_dict[actor_id] = next_bacon
#            path[actor_id] = current_a
#            break
#        else:
#            for i in next_a:
#                if next_bacon < bacon_dict[i]:
#                    bacon_dict[i] = next_bacon
#                    path[i] = current_a
#        unlabel.remove(current_a)
#        
#    shortest = []
#    current_a = actor_id
#
#    if current_a not in path:
#        return None
#    elif path[current_a] == None:
#        return None
#    else:
#        while path[current_a] != None:
#            shortest.insert(0, current_a)
#            current_a = path[current_a]
#        
#    if shortest != []:
#        shortest.insert(0, current_a)
#    else:
#        return None
#    
#    return shortest
    
    social_actor = get_social(data)
    neighbor_actor = social_actor.get_all_neighbor()
    start = 4724
    path_total = []
    path_total.append([start])
    visited = set()
    current_i = 0
    while current_i < len(path_total):
#        print(path_total, visited)
#        path = path_total.pop(0)
        path = path_total[current_i]
        actor = path[-1]
        if actor not in visited:
            visited.add(actor)
            next_a = neighbor_actor[actor]
            for i in next_a:
                if i in visited:
                    continue
                else:
                    shortest = path.copy()
                    shortest.append(i)
                    if i == actor_id:
#                        print(shortest)
                        return shortest
                    path_total.append(shortest)
        current_i += 1
    return  

def get_path(data, actor_id_1, actor_id_2):
#    bacon_dict = {}
#    path = {}
#    unlabel = get_all_actor(data)
#    for i in unlabel:
#        path[i] = None
#        bacon_dict[i] = float('inf')
#        
#    start = actor_id_1     # initialize actor with bacon number 0
#    bacon_dict[start] = 0
#    while unlabel:
#        current_a = min(unlabel, key = lambda actor: bacon_dict[actor])
#        print(bacon_dict[current_a])
#        if bacon_dict[current_a] > 6:
#            break
#        next_a = get_next_actor(data, current_a)
#        next_bacon = bacon_dict[current_a] + 1
#        if actor_id_2 in next_a:
#            if next_bacon < bacon_dict[actor_id_2]:
#                bacon_dict[actor_id_2] = next_bacon
#                path[actor_id_2] = current_a
#                continue
#        else:
#            for i in next_a:
#                if i not in unlabel:
#                    continue
#                if next_bacon < bacon_dict[i]:
#                    bacon_dict[i] = next_bacon
#                    path[i] = current_a
#        unlabel.remove(current_a)
#        
#    shortest = []
#    current_a = actor_id_2
#
#    if path[current_a] == None or current_a not in path:
#        return None
#    else:
#        while path[current_a] != None:
#            shortest.insert(0, current_a)
#            current_a = path[current_a]
#        
#    if shortest != []:
#        shortest.insert(0, current_a)
#    else:
#        return None
#    
#    return shortest

#    start = actor_id_1
#    stack = [start]
#    path_total = [[start]]
##    visited = []
#    while stack:
#        actor = stack.pop()
#        path = path_total.pop()
##        print('actor:' + str(actor))
##        if actor in path:
##            continue
##        else:
##            path.append(actor)
#        next_a = get_next_actor(data, actor)
##        for actor_id in set(next_a) - set(path):
##            print(actor_id)
##            if actor_id == actor_id_2:
##                if path + [actor_id] in path_total:
###                    print(path_total)
##                    return path_total
##                else:
##                    path_total.append(path + [actor_id])
###                    path = []
##                    break
###                    print(path_total)
##            else:
###                print(actor)
##                stack.append(actor_id)
#        for next in set(next_a) - set(path):
#            if next == actor_id_2:
#                yield path + [next]
#            else:
#                path_total.append(path + [next])
#                stack.append(next)
    
#    return path_total
    
    social_actor = get_social(data)
    neighbor_actor = social_actor.get_all_neighbor()
    start = actor_id_1
    path_total = []
    path_total.append([start])
    visited = set()
    current_i = 0
    while current_i < len(path_total):
#        print(path_total, visited)
#        path = path_total.pop(0)
        path = path_total[current_i]
        actor = path[-1]
        if actor not in visited:
            visited.add(actor)
            next_a = neighbor_actor[actor]
            for i in next_a:
                if i in visited:
                    continue
                else:
                    shortest = path.copy()
                    shortest.append(i)
                    if i == actor_id_2:
#                        print(shortest)
                        return shortest
                    path_total.append(shortest)
        current_i += 1
    return  

def movie_path(data, actor_id_1, actor_id_2):
    film_dict = get_film(data)
    path = get_path(data, actor_id_1, actor_id_2)
    film_list= []
    for i in range(len(path) - 1):
        if (path[i], path[i+1]) in film_dict:
            film_list.append(film_dict[(path[i], path[i+1])])
    return film_list
 
if __name__ == '__main__':
#    with open('resources/small.json') as f:
#        smalldb = json.load(f)

    # additional code here will be run only when lab.py is invoked directly
    # (not when imported from test.py), so this is a good place to put code
    # used, for example, to generate the results for the online questions.
    with open('resources/tiny.json') as f:
        result = json.load(f)
##    print(result['Katarina Cas'])
    for name, v in result.items():
        if v == 83462:
            print(name)
            break
#    print(result['Buck Henry'])